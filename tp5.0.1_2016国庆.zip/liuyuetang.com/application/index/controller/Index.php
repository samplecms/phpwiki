<?php
namespace app\index\controller;

class Index extends \app\common\FrontController
{
    public function index()
    {
    	 

        return  $this->make('/index');
    }

    

}
