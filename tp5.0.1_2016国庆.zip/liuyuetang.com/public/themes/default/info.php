<?php 

return [

	'title' => '吴式太极', 
	'subtitle'=>'年轻人学太极拳 ',
];